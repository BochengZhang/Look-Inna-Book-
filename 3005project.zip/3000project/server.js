const express = require ('express');
const session = require('express-session')
const app = express();
const pug = require('pug');
const fs=require('fs');
app.set("view engine", "pug");
app.use(express.static("./view/Pug"));
app.use(express.static("./view/css"));
app.use(express.static("./view"));
app.use(express.urlencoded({extended: true}));
app.use(session({ secret: 'some secret here'}))
app.use(express.json());

const {Client} = require("pg");
const db =new Client({
    host:"localhost",
    user:"postgres",
    port: 1500,
    password:"    ",
    database:"test"
});

db.connect();
/*app.get("/", function (req, res) {
    var query = "SELECT * FROM Author";
    //executeQuery(res, query);
    db.query(query,(err,sql_res)=>{
        if(err) throw err;
        console.log(sql_res.rows);
        res.send(sql_res.rows);
    })
})*/
app.get("/",homepage);

app.get("/signin", function(req,res){
    if(!req.session.loggedin){
        res.format({"text/html":()=>res.status(200).redirect("/SignIn.html")});
     }else{
        res.status(200).redirect("/");
     }
})
app.get("/Book/:isbn",BookPage);
app.get("/BookStore/:BS_ID", BookStorePage);
app.get("/customer",auth,CustomerPage);
app.get("/Basket/:Basket_id", BasketPage);
app.get("/Owner", OwnerLoginPage);
app.get("/Owner/:id", OwnerPage);
app.get("/Edit",EditPage);

app.post("/SignIn.html", login, homepage);
app.post("/", search);
app.post("/Book/:isbn",auth,BasketAdd);
app.post("/SignUp.html", signup);
app.post("/Basket/:Basket_id", auth,CheckOut);
app.post("/BookStore/:BS_ID", auth,Register);
app.post("/Owner", OwnerLogin);
app.post("/delete", DeleteBook);
app.post("/add",AddBook);
function AddBook(req,res){
    let owner = req.session.Owner
    let bookstore = req.session.bookstore;
    let title = req.body.title;
    let isbn = req.body.ISBN;
    let page = req.body.pages;
    let price = req.body.price;
    let rate = req.body.Rate;
    let pname = req.body.name;
    let bank = req.body.account;
    let email = req.body.email;
    let add = req.body.address;
    let province = req.body.province;
    let postcode = req.body.postcode;
    let amount = req.body.amount;
    console.log(price);
    console.log(rate);
    var query = "insert into publisher values (default, $1,$2,$3,$4,$5,$6)"
    let values=[pname,province, postcode,add,bank,email];
    db.query(query,values,(err, sql_res)=>{
        if(err) throw err;
        console.log("success to insert the publisher");
        query = "select * from publisher where name = $1 and province = $2 and bank_account = $3 ";
        values=[pname, province,bank];
        db.query(query,values,(err, sql_res)=>{
            if(err) throw err;
            let p_id = sql_res.rows[0].id;
            query = "insert into book values ($1,$2,$3,$4,$5,$6)";
            values=[isbn,title,page,price,rate,p_id];
            db.query(query,values,(err,sql_res)=>{
                if(err) throw err;
                query = "insert into sell values ($1,$2,$3)";
                values =[bookstore.bookstore_id,isbn,amount];
                db.query(query,values,(err,sql_res)=>{
                    if(err) throw err;
                    console.log("success for to insert a book!");
                    res.status(200). send(pug.renderFile("./view/Pug/AddBook.pug",{Owner:owner, err:"SUCCESS TO INSERT A BOOK"}));
                })

            })
        })
    })
}
function DeleteBook(req,res){
    let owner = req.session.Owner;
    let bookstore = req.session.bookstore;
    let isbn = req.body.isbn;
    var query = "select * from sell where isbn = " +isbn +" and bs_id = "+bookstore.bookstore_id;
    db.query(query,(err, sql_res)=>{
        if(err) throw err;
        if(sql_res.rows.length>0){
            query = "delete from sell where bs_id = "+bookstore.bookstore_id+" and isbn = "+isbn;
            db.query(query,(err,sql_res)=>{
                if(err) throw err;
                 res.status(200). send(pug.renderFile("./view/Pug/AddBook.pug",{Owner:owner, err:"DELETE SUCCESS"}));
            })
        }else{
             res.status(200). send(pug.renderFile("./view/Pug/AddBook.pug",{Owner:owner, err:"ISBN NOT FOUND TO DELETE"}));
        }
    })
}
function EditPage(req, res){
    let owner = req.session.Owner;
    res.status(200). send(pug.renderFile("./view/Pug/AddBook.pug",{Owner:owner}));
}

function OwnerPage(req,res){
    let owner = req.session.Owner;
    var query = "select * from bookstore where owner_id = "+owner.id;
    db.query(query,(err, sql_res)=>{
        if(err) throw err;
        let bookstore = sql_res.rows[0];
        //console.log(sql_res.rows[0]);
        req.session.bookstore = bookstore;
        //console.log(bookstore.id);
        query = "select * from publisher,(select * from sell join book using (isbn)) as foo where publisher.id = foo.p_id and bs_id ="+bookstore.bookstore_id;
        //console.log(query);
        db.query(query,(err, sql_res)=>{
            if(err) throw err;
            let Book = sql_res.rows
            var process_count = 0;
            let email =[];
            if(process_count == 0){
                for (var i=0; i<sql_res.rows.length;i++){
                    if(sql_res.rows[i].count < 10){
                        email.push(sql_res.rows[i]);
                    }
                }
                process_count=1;
            }
            if(Book&&process_count==1){
                query = "select * from OrderInfo where o_id = "+owner.id;
                db.query(query,(err, sql_res)=>{
                    if(err) throw err;
                    let Orders = sql_res.rows;
                    res.status(200).send(pug.renderFile("./view/Pug/Ownerpage.pug",{Owner:owner, Bookstore:bookstore,Book:Book, Email:email, Orders:Orders}))
                })

            }
        })

    })
}

function OwnerLogin(req,res){
    let email = req.body.email;
    let pass = req.body.password;
    query = "select * from owner where email = '" + email+"'";
    db.query(query,(err,sql_res)=>{
        if(err) throw err;
        if(sql_res.rows[0]&&sql_res.rows[0].pass == pass){
            req.session.OwnerLogin = true;
            req.session.Owner = sql_res.rows[0];
            res.status(200).redirect("/Owner/"+sql_res.rows[0].id);
            //next();
        }else{
            res.status(200).redirect("/Owner");
        }
    })
}

function OwnerLoginPage(req,res){
    if(!req.session.Ownerlogin){
        res.status(200).send(pug.renderFile("./view/Pug/Owner.pug"));
    }else{
        res.send("Already login as Owner");
    }
}
function Register(req,res){
    let user = req.session.user;
    let StoreID = req.params.BS_ID;
    var query="select u_id from Register where bs_id = "+ StoreID;
    db.query(query,(err,sql_res)=>{
        if(err) throw err;
        let list = [];
        for(var i=0; i<sql_res.rows.length;i++){
            list.push(sql_res.rows[i].u_id);
        }
        if(list.includes(user.id)){
            res.send("You Already Register!");
        }else{
            query = "insert into Register values ("+user.id+","+StoreID+")";
            db.query(query,(err, sql_res)=>{
                if(err) throw err;
                console.log("Success to Register in store with ID = " + StoreID);
            })
        }
    })
}

function CheckOut(req,res){
    let user = req.session.user;
    let ID = req.params.Basket_id;
    let phone = req.body.phone;
    let add = req.body.address;
    let postcode = req.body.postcode;
    let province = req.body.province;
    if(phone==""){
        phone = user.phone_num;
    }
    if(add==""){
        add=user.address;
    }
    if(postcode==""){
        postcode = user.postal_code;
    }
    if(province==""){
        province = user.province;
    }
    var d = new Date();
    console.log(d.getMonth());
    var day = ""+d.getFullYear()+"-"+ d.getMonth()+"-"+d.getDate();
    var query="select bookstore_name from basket where ID = " + ID;
    db.query(query, (err, sql_res)=>{
        if(err) throw err;
        let storeName = sql_res.rows[0].bookstore_name;
        console.log(storeName);
        query="select bs_id from Register where u_id = " + user.id;
        db.query(query,(err, sql_res)=>{
            if(err) throw err;
            let list =[];
            for(var i=0; i<sql_res.rows.length;i++){
                list.push(sql_res.rows[i].bs_id);
            }
            query="select * from bookstore where name = '"+storeName+"'";
            db.query(query,(err, sql_res)=>{
                if(err) throw err;
                let StoreID = sql_res.rows[0].bookstore_id;
                let OwnerID = sql_res.rows[0].owner_id;
                //console.log(StoreID);
                if(list.includes(StoreID)){
                    query = "update basket set state = 'checkout' where id = "+ID;
                    db.query(query, (err, sql_res)=>{
                        if(err) throw err;
                        console.log("Successful to change state to checkout!")
                        query = "select ISBN, title, num, price, num*price as total from (select * from takes natural join book) as foo where id =" +ID;
                        db.query(query,(err, sql_res)=>{
                            if(err) throw err;
                            console.log(sql_res.rows);
                            let Basket_Detail=sql_res.rows;
                            console.log(Basket_Detail);
                            let total=0;
                            var queryII="";
                            for(var i=0; i<sql_res.rows.length;i++){
                                total += parseFloat(sql_res.rows[i].total);
                                //console.log(sql_res.rows[i].total);
                                queryII+="update sell set count= count -" +sql_res.rows[i].num+" where bs_id = "+StoreID+" and isbn ="
                                        +sql_res.rows[i].isbn+ "; ";
                            }
                            console.log(queryII);
                            if(total>0){
                                query = "insert into orderinfo values (default, $1, $2, $3,$4,$5,$6,$7,$8,$9)";
                                let values = [ID, user.id,OwnerID,phone,postcode,province,add,total,day];
                                db.query(query,values,(err,sql_res)=>{
                                    if(err) throw err;
                                    console.log("successful to check out");
                                    if(queryII!=null){
                                        db.query(queryII,(err,sql_resII)=>{
                                            if(err) throw err;
                                            console.log("reduce the book storage from book store");
                                            query = "select * from (select  *  from book join (select OrderInfo.id, basket_id, isbn, num, total, buy_day, address, postal_code, phone_num, province from OrderInfo, takes where OrderInfo.basket_id = takes.id) as foo using (ISBN)) as tem where basket_id = "+ID;
                                            db.query(query, (err, sql_res)=>{
                                                res.status(200).send(pug.renderFile("./view/Pug/bill.pug",{result: sql_res.rows}))
                                            })
                                        })
                                    }
                                })
                            }
                        })
                    })

                }else{
                    res.redirect("/bookstore/"+StoreID);
                }

            })

        })
    })

}

function BasketPage(req, res){
    let Basket_ID = req.params.Basket_id;
    var query = "select * from book, (select * from basket left join takes using(id) where id ="+ Basket_ID +") as foo"
                 +" where book.isbn = foo.isbn";
    db.query(query, (err, sql_res)=>{
        if(err) throw err;
        query = "select id from orderInfo where basket_id = " + Basket_ID
        db.query(query,(err, sql_resII)=> {
            if(err) throw err;
            console.log(sql_resII.rows[0]);
            if(sql_resII.rows[0] != null){
                res.status(200).send(pug.renderFile("./view/Pug/basket.pug",{basket: sql_res.rows, Order: sql_resII.rows[0].id}));
            }else{
                res.status(200).send(pug.renderFile("./view/Pug/basket.pug",{basket: sql_res.rows}));
            }
        })
    })
}

function BasketAdd(req,res){
    let isbn = req.params.isbn;
    let user = req.session.user;
    let count = req.body.number;
    let store = req.body.Bookstore;
    var query = "select * from basket"+
                 " where state = 'processing' and c_id = " + user.id+ " and bookstore_name = '" + store+"'";
    db.query(query,(err, sql_res)=>{
        if (err) throw err;
        if(sql_res.rows.length>0){
            let basket = sql_res.rows[0];
            console.log(basket);
            query = "select * from takes where id = "+ basket.id + " and ISBN = " + isbn;
            db.query(query, (err, sql_res)=>{
                if(err) throw err;
                var queryII= null;
                if (sql_res.rows.length>0){
                    queryII = "update takes set num = num + " + count + "where id = " + basket.id;
                }else {
                    queryII = "insert into takes values ( "+basket.id+", "+ isbn+ ", "+count+")";
                }
                if(queryII != null){
                    db.query(queryII,(err, sql_resII)=>{
                        if(err) throw err;
                        console.log("success to add to basket!");
                    })
                }
            })

        }else{
            query = "insert into Basket values (default, '"+user.id+"', '"+store+"', 'processing')";
            db.query(query,(err, sql_res)=>{
                if(err) throw err;
                query = "select id from Basket where state='processing' and c_id = " + user.id +" and bookstore_name = '"+store+"'"
                db.query(query,(err,sql_res)=>{
                    if(err) throw err;
                    var basketID = sql_res.rows[0].id;
                    query = "insert into takes values ( "+basketID+", "+isbn+", "+count+")";
                    console.log(query);
                    db.query(query,(err, sql_res)=>{
                        if(err) throw err;
                        console.log("insert success!");
                    })
                })
            })
        }
    })
}



function CustomerPage(req,res){
    let user = req.session.user;
    var query = "select * from basket where c_id = " + user.id;
    db.query(query,(err,sql_res)=>{
        if(err) throw err;
        let processing=[];
        let checkout = [];
        for(var i=0; i< sql_res.rows.length;i++){
            if (sql_res.rows[i].state == "processing"){
                processing.push(sql_res.rows[i]);
            }else{
                checkout.push(sql_res.rows[i]);
            }
        }
        res.status(200).send(pug.renderFile("./view/Pug/Customer.pug",{user:user, basket: processing,history:checkout}));
    })
}

function search(req,res){
    let searchType = req.body.Sort;
    let keyWord = req.body.KeyWord;
    if(searchType == "ISBN" && isNaN(keyWord)){
        res.status(200).send(pug.renderFile("./view/Pug/home.pug",{err:"Please Input a Number for ISBN Search!"}));
    }else{
        var query = null;
        if(searchType != "GENRE" && searchType != "AUTHOR"){
            query = "select * from book where " +searchType + " = '"+keyWord+"'";
        }else if (searchType == "GENRE") {
            query = "select * from book where isbn in (select isbn from genre where name = '" + keyWord +"')";
        }else if (searchType == "AUTHOR"){
            query = "select * from book where isbn in (select distinct isbn from"
            +"(select * from author, wrote where author.id = wrote.author_id) as Author_info "
            + "where name = '"+keyWord+"')";
        }
       // console.log(query);
        if(query != null){
            db.query(query,(err,sql_res)=>{
                if(err) throw err;
                //console.log(sql_res.rows);
                var ListISBN = [];
                for(var i=0; i< sql_res.rows.length;i++){
                    ListISBN.push(sql_res.rows[i].isbn);
                }
                queryII = "select distinct bookstore_id, name from (select * from bookstore, sell where bookstore.Bookstore_ID = sell.bs_id) as foo "+
                "where isbn in (" + ListISBN+")";
                if (ListISBN.length>0){
                    db.query(queryII,(err, sql_resII)=>{
                         if(err) throw err;
                         //console.log(sql_resII.rows);
                         res.status(200).send(pug.renderFile("./view/Pug/home.pug",{BookStore: sql_resII.rows}));
                    })
                }else{
                        res.status(200).send(pug.renderFile("./view/Pug/home.pug",{}));
                }
            })
        }
    }
}

function signup(req,res,next){
    let name=req.body.name;
    let username = req.body.username;
    let password = req.body.password;
    let province = req.body.province;
    let address = req.body.address;
    let postalC = req.body.postalcode;
    let email = req.body.email;
    let phonenum = req.body.phonenum;
    var query = "select * from customer where username = '" +username+"'";
    db.query(query,(err,sql_res)=>{
        if(err) throw err;
        if(sql_res.rows.length!=0){
            console.log("ERR: sign up fail because username exit!")
            res.status(201).send("Already exit!")
        }else{
            let queryI = "insert into customer values (default, $1,$2,$3,$4,$5,$6,$7,$8)";
            var values=[name,username,password,phonenum,postalC,province,address,email];
            db.query(queryI,values,(err, sql_resII)=>{
                if(err) throw err;
                console.log("sign up success!");
                res.format({"text/html":()=>res.status(200).redirect("/SignIn.html")});
            })
        }
    })
}

function BookStorePage(req,res){
    let id = req.params.BS_ID;
    var query = "select * from BookStore where bookstore_id = " + id;
    db.query(query,(err, sql_res)=>{
        if(err) throw err;
        query = "select * from sell join book using (isbn) where bs_id = "+id;
        db.query(query,(err,sql_resII)=>{
            if(err) throw err;
           // console.log(sql_resII.rows);
            res.status(200).send(pug.renderFile("./view/Pug/bookstore.pug",{BookStore: sql_res.rows[0],Books:sql_resII.rows}));
        })
    })
}
function BookPage(req,res){
    let isbn = req.params.isbn;
    var query = "select * from (select * from book, publisher where book.P_id = publisher.id) as full_info where isbn = '" +isbn+ "'";
    var Book_info = null;
    var Book_Genre=null;
    var Book_Store= null;
    db.query(query,(err,sql_res)=>{
        if(err) throw err;
        Book_info = sql_res.rows[0];
        var queryII = "select * from Genre where isbn = '" + isbn +"'";
        db.query(queryII,(err,sql_res)=>{
            if(err) throw err;
            Book_Genre = sql_res.rows;
            var queryIII = "select * from bookstore where bookstore_id in ( select bs_id from sell where isbn = '"+isbn+"')";
            db.query(queryIII,(err, sql_res)=>{
                if(err) throw err;
                //console.log(sql_res.rows);
                req.session.bookstore = sql_res.rows;
                Book_Store = sql_res.rows;
                var queryIV = "select * from (select * from author, wrote where author.id = wrote.id) as foo where isbn = "+isbn
                 db.query(queryIV,(err, sql_res)=>{
                    if(err) throw err;
                        //console.log(sql_res.rows);
                        res.status(200).send(pug.renderFile("./view/Pug/book.pug",{Book:Book_info, store: Book_Store, Genre: Book_Genre, Author:sql_res.rows}));
                 })
            })
        })
    })
}



function homepage(req,res){
    res.status(200).send(pug.renderFile("./view/Pug/home.pug"));
}

function login (req, res, next){
    let username = req.body.username;
    let password = req.body.password;
    //let username = "BCOwner";
    //let password = "pass";
    /*string PassSearch = "select pass from Customer where username = ?";
    PreparedStatement getPass = db.prepareStatement(PassSearch);
    PassSearch.setString(1,name);*/
    var query = "select * from Customer where username ='" + username+"'";
    db.query (query,(err,sql_res)=>{
         if(err) throw err;
         //console.log(sql_res);
         console.log(sql_res.rows[0].pass);
         if(sql_res!=null&&sql_res.rows[0].pass==password){
             req.session.loggedin=true;
             req.session.username = username;
             req.session.user = sql_res.rows[0];

             console.log(req.session.user);
             next();
         }else{
             //res.getWriter().print("alter ('wrong')");
             res.send("Password Or UserName Undefined!");
         }
    })
}

function auth(req,res,next){
    if(!req.session.loggedin){
       return res.redirect("/SignIn.html");
    }
    next();
}

app.listen(3000, () => {
  console.log(`Example app listening at http://localhost:${3000}`)
});