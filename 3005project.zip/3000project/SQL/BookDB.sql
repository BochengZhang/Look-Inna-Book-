delete from Publisher;
delete from Book;
delete from Author;
delete from wrote;
delete from Genre;
delete from Customer;
delete from Owner;
delete from BookStore;
delete from register;
delete from Basket;

delete from sell;
delete from OrderInfo;
delete from takes;
delete from shipping_info;
/*Publish*/
insert into Publisher values(default,'Penguin Press', 'ON', 'K1S4P2', '303 NorthPoll Street', 5729478330178324, 'PenguinP@124.com');
insert into Publisher values(default,'Doubleday Canada',  'ON','K1S4Q2', '305 SouthPoll Street',  8729376109385736, 'DoubledayC@gmail.com');
insert into Publisher values(default,'Kindle SM','BC', 'J3QH9O', '#1-14592 SunnySide',  8237898274910827,'KindleSM@gmail.com');
insert into Publisher values(default,'BigBlueInput',  'VC','Q8II6O', '#5-19 DarkSide',  8934820398471930,'BBInput@gmail.com');
insert into Publisher values(default,'Gaynamee',  'AB','S1NM1K', '123 MediaSide', 1390285738291239, 'Gaynamee@334.com');

/* Book */
insert into Book values (0385685548, 'Go Tell the Bees That I Am Gone: A Novel', 200, 27.00, 0.20, 1);
insert into Book values (1514335506, 'Dark Stranger The Dream',  199, 17.01, 0.15, 1);
insert into Book values (1183750923, 'Outlander',  642, 43.03, 0.23, 2);
insert into Book values (1986076016, 'Flame and Ember',  266, 16.99, 0.09, 4);
insert into Book values ( 1984877925, 'Will', 432, 34.30, 0.11, 1);


/*Author*/
insert into Author values(default,'Diana Gabaldon', 'gabaldon@gmail.com');
insert into Author values(default,'Isabell T. Lucas', 'IsabellLucas@gmail.com');
insert into Author values(default,'M.A. Nichols', 'Nichols@gmail.com');
insert into Author values(default,'Will Smtith', 'WillS@gmail.com');
insert into Author values(default,'Mark Manson', 'MarkManson@gmail.com');

/*write*/
insert into Wrote values(1, 0385685548);
insert into Wrote values(2, 1514335506);
insert into Wrote values(1, 1183750923);
insert into Wrote values(3, 1986076016);
insert into Wrote values(4, 1984877925);
insert into Wrote values(5, 1984877925);


/*Genre*/
insert into Genre values('Action',  0385685548);
insert into Genre values('Action',  1514335506);
insert into Genre values('Fiction', 0385685548);
insert into Genre values('Art', 0385685548);
insert into Genre values('Art', 1183750923);
insert into Genre values('Nonfiction', 1986076016);
insert into Genre values('Biology', 1984877925);

/*Customer*/
insert into Customer values(default,'Bocheng Zhang', 'BCOwner','pass', 6187339097, 'K1S4J9', 'ON', '303 Bell Stree', 'bochengzhang@gmail.com');
insert into Customer values(default,'Zack Alhmod','ZALhomd','pass', 1782930987, 'K13S9J', 'ON', '343 HelloRoad','ZackA@gmail.com');
insert into Customer values(default,'AlooK Mohamen', 'Normal','pass', 8925670913, 'K1S4Q2', 'VC', '123 Darkside','AlookMoham@gmail.com');

/*Owner*/
insert into Owner values(default,'pass','Bocheng Zhang', 'bochengzhang@gmail.com', 6187339097);
insert into Owner values(default,'pass','Wendy Smith', 'Wendy@gmail.com', 8972679872);

/*BookStore*/
insert into BookStore values(default,'MyBookStore','123 HelloRoad', 'ON', 1);
insert into BookStore values(default,'BookStoreII','222 NiceRoad', 'ON', 2);

/*register*/
insert into register values(1,1);
insert into register values(1,2);
insert into register values(2,1);
insert into register values(3,1);

/*Basket*/
insert into Basket values(default, 1, 'MyBookStore','processing');

/*store*/
insert into sell values(1,0385685548, 20);
insert into sell values(1,1514335506, 11);
insert into sell values(2,1986076016,30);
insert into sell values(1,1183750923,12);
insert into sell values(2,1984877925,32);
insert into sell values(1,1984877925,12);


