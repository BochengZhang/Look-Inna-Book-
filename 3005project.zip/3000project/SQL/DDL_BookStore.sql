create table Publisher
    (ID         serial,
     Name    varchar(100) not null,
     province   char(2),
     Postcode char(6),
     Address    varchar(100),
     Bank_Account numeric(16,0) not null,
     email varchar(100) not null,
     primary key (ID)
    );
	
create table Book
	(ISBN		numeric(10,0) not null,
	 title		varchar(100) not null,
	 Page_num   int,
     price      numeric(8,2),
     Rate_of_Transfer numeric(2,2),
     P_Id  int,
	 primary key (ISBN),
     foreign key (P_Id) references Publisher(ID)
        on delete set null
	);

create table Genre
    (name      varchar(100) not null,
     ISBN      numeric(10,0) not null,
     foreign key (ISBN) references Book(ISBN)
        on delete cascade
    );

create table Author
    (ID         serial,
     Name      varchar(100) not null,
     email      varchar(100),
     primary key (ID)
    );

create table Wrote
    ( ID int,
      ISBN numeric(10,0),
      primary key (ID, ISBN),
      foreign key (ID) references Author(ID)
        on delete cascade,
      foreign key (ISBN) references Book(ISBN)
        on delete cascade
    );

create table Customer
    (ID         serial,
     Name       varchar(100),
     Username   varchar(20) not null,
     pass       varchar(10), 
     phone_num  numeric(10,0),
     postal_code char(6),
     province   char(6),
     Address    varchar(100),
     email      varchar(100),
     primary key (ID)
    );

create table Owner
    (ID         serial,
     pass       varchar(30),
     Name       varchar(100),
     email      varchar(100),
     phone_num  numeric(10, 0),
     primary key (ID)
    );

create table BookStore
    (BookStore_id serial,
     Name         varchar(50) unique,
     Address      varchar(100),
     province     char(2),
     Owner_id      int,
     primary key(BookStore_id),
     foreign key (Owner_id) references Owner(ID)
        on delete cascade
    );

create table Basket
    (ID         serial,
     C_ID       int,
     Bookstore_Name varchar,
     state      varchar(20),
     primary key (ID),
     foreign key (C_ID) references Customer(ID)
        on delete cascade
    );


create table OrderInfo
    (ID         serial,
     Basket_ID   int,
     C_ID       int,
     O_ID       int,
     phone_num  numeric(10,0),
     postal_code char(6),
     province   char(2),
     Address    varchar(100),
     total      numeric(8,2),
     buy_day    Date,
     primary key (ID),
	 foreign key (Basket_id) references Basket(ID),
	 foreign key (C_ID) references Customer(ID),
	 foreign key (O_ID) references Owner(ID)

    );

create table shipping_info
    (ID         serial,
     state      varchar(20),
     O_ID       int,
     primary key (ID),
     foreign key (O_ID) references OrderInfo(ID)
    );


create table takes
    (ID    int,
     ISBN    numeric(10,0),
     num     int check(num > 0),
     primary key (ID, ISBN),
     foreign key (ISBN) references Book(ISBN)
        on delete cascade,
     foreign key (ID) references Basket(ID)
        on delete cascade
    );

create table register
    (u_id       int,
     BS_id      int,
     primary key(u_id, BS_id),
     foreign key (u_id) references Customer(ID),
     foreign key (BS_id) references BookStore(BookStore_id)
        on delete cascade
    );

create table sell
    (BS_ID      int,
     ISBN       int,
     count      int,
     primary key (BS_ID,ISBN),
     foreign key (BS_ID) references BookStore(BookStore_id)
        on delete cascade,
     foreign key (ISBN) references Book(ISBN)
        on delete cascade
    );







